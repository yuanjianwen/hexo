---
title:
date: 2018-08-29 02:10:08
---
# Scope
The topics of interest include, but are not limited to:

-	Artificial Intelligence
-	Machine Learning
-	Big Data Analytics
-	Software Engineering
-	Digital Signal/Image/Audio Processing
-	Pattern Recognition
-	Computer Graphics
-	Power Electronics
-	Fuzzy Sets And Fuzzy Logic
-	Wireless Communications
-	Wireless Networks
-	Mobile Computing
-	Software Defined Wireless Networks
-	Information Security

---

# Submission

- Each paper should be written in English, whose length should not be less than 4 pages. It could be one of two types of papers: research paper and survey paper, and should follow the [IEEE format](http://www.ieee.org/conferences_events/conferences/publishing/templates.html).

- Each paper should be submitted in PDF. The paper submission information (such as website and email) will be announced later.

- Please click **[HERE](http://google.com/)** to submit paper.
