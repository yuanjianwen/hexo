---
title:
date: 2018-08-29 10:21:18

---

# Address: Avenida Wai Long,Taipa,Macau

<iframe src="http://www.google.cn/maps/embed?pb=!1m18!1m12!1m3!1d7390.648768222051!2d113.56294173071231!3d22.151721014595346!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x34017006a1f9e4bf%3A0x6613e1cd6c7f1d18!2sMacau+University+of+Science+and+Technology%2C+Macau!5e0!3m2!1sen!2scn!4v1535596417881" align="middle" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
