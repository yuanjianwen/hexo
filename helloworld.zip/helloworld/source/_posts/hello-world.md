title: <p style="display:none;"> Please read carefully </p>

---
## Goal

The 2nd PhD Student Seminar 2018 provides a platform for FI PhD students to meet together and discuss their research findings and the latest advancements in their own disciplines. The seminar seeks original, UNPUBLISHED research papers reporting the latest research of each PhD student.

---

## Important date

<font color = red> Abstact Due:       September 6, 2018 (tentative)
Full Paper Due:     September 6, 2018 (tentative)
Oral Presentation: 	 September 13, 2018 (tentative)</font><br>


 English is the official language for the presentation. The power point file (ppt) for oral presenation should also be submitted before the formal oral presentation. More details on the scheduling of oral presentation will be announced later.


---


## Fi policy for PHD students

FI PhD course, DIIZ11 (LITERATURE SURVEY AND THESIS PLANNING), consists of FI PhD Student Seminar (20% of the total score) and Fl PhD Proposal Defense (80% of the total score). Before applying for the PhD Proposal Defense, a PhD student MUST attend the PhD Student Seminar (each student is required to submit an annual report and conduct an oral presentation).

---

## Contact

For any inquiry , please contact Joey Wong at 8897-2240 or email by lmawong@must.edu.mo.

---
